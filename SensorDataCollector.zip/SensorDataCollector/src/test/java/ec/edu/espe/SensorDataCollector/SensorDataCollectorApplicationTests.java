package ec.edu.espe.SensorDataCollector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SensorDataCollectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
