package ec.edu.espe.SensorDataCollector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SensorDataCollectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SensorDataCollectorApplication.class, args);
	}

}
