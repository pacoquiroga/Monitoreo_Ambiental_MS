package ec.edu.espe.NotificationDispatcher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationDispatcherApplicationTests {

	@Test
	void contextLoads() {
	}

}
