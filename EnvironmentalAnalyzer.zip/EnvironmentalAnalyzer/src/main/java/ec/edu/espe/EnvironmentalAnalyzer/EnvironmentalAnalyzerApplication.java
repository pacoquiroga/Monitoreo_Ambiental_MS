package ec.edu.espe.EnvironmentalAnalyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnvironmentalAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnvironmentalAnalyzerApplication.class, args);
	}

}
