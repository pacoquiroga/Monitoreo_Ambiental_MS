package ec.edu.espe.EnvironmentalAnalyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvironmentalAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
